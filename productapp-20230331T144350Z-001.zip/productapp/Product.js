import React from 'react';

import {Card, CardBody, CardText} from 'reactstrap';

const Product=({pd})=>{
    return(
        <Card>
            <CardBody>
                <CardText>Product id : {pd.prodId}</CardText>
                <CardText>Product Name : {pd.prodName}</CardText>
                <CardText>Price : {pd.price}</CardText>               
            </CardBody>
        </Card>

    )
}

export default Product;