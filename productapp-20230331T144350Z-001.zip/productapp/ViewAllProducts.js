
import axios from 'axios';
import React, { useEffect, useState } from 'react';
import Product from './Product';
import base_url from './Api';
const ViewAllProducts = () => {
    useEffect(()=>{document.title="View Products"},[]);
  
    const getAllProducts = () => {
      axios
        .get(`${base_url}/products`) 
        .then((result) => {
            console.log('hi')
          console.log(result.data);
          setProduct(result.data);
        })
        .catch((err) => {
          console.log(err);
        });
    };
  
    useEffect(() => {
      getAllProducts();
    }, []);
  
    const [products, setProduct]=useState([]);
    
    return (
        <div>
          <h1 className="text-center">All Products</h1>
          { 
              products.length>0?products.map((prod) => 
                  <Product pd={prod} key={prod.prod_id}/> ): "No Products"
              } 
       </div>
      );
  };
  
  export default ViewAllProducts;