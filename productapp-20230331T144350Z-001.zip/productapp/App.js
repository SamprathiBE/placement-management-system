
import './App.css';
import ViewAllProducts from './components/ViewAllProducts';
function App() {
  return (
    <div className="App">
      <ViewAllProducts/>
    </div>
  );
}

export default App;
